export class LoginData {
  static get validCredentials() {
    return {
      username: "ext-freygom",
      password: "Fer1123@",
    };
  }
}
